//Exercício 1:
//Criar um programa que leia 4 números, armazene em um vetor e calcule a média.

# include <stdio.h>

int main(){

    int numeros[4];

    printf("Digite quatro numeros: \n");
    for (int i = 0; i < 4; i++){
        printf("\nNumero %d: ", i+1);
        scanf(" %d", &numeros[i]);
    }
    float media = 0;

    for(int i = 0; i < 4; i++){
        media += numeros[i];
    }
    media /= 4;
    printf("\n");
    printf("Essa e a media dos numeros digitados: %.2f ", media);
    return 0;
}
