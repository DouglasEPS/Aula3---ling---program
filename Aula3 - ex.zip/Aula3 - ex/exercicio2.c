//Exercício 2:

//Ler 5 números e mostrar apenas os números maiores que 10.

# include <stdio.h>

int main(){
    int numeros[5];
    int maior[5];

    printf("Digite cinco numeros: \n");
    for (int i = 0; i < 5; i++){
        printf("\nNumero %d: ", i+1);
        scanf(" %d", &numeros[i]);
    }

    for (int i = 0; i < 5; i++){
        if (numeros[i] > 10){
            maior[i] = numeros[i];
        } else{
            maior[i] = 0;
        }
    }
    printf("\nAqui estao os valores digitados maiores que zero: \n");
    
    for (int i = 0; i < 5; i++){
        if(maior[i] != 0){
            printf("Numero: %d", maior[i]);
        }
    }
    return 0;
}


