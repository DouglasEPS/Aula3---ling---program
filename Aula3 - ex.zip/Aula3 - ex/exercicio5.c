//Exercício 5: 
//Matriz 2×3 - contar quantos elementos são maiores que 5

# include <stdio.h>

int main() {
    int matriz[2][3];
    int aux = 0;
    int num[6];
    int cont = 0;
    
    //insere os valores que quiser
    printf("Digite os valores da matriz\n");
    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 3; j++){
            printf("Elemento[%d][%d]: ", i+1, j+1);
            scanf("%d", &matriz[i][j]);
        }
    }

    printf("\nMatriz digitada:\n");
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n"); // quebra linha a cada linha da matriz
    }
    //numeros da matriz > 5. contar quantos + armazenar quais.
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
           if(matriz[i][j] > 5){
            cont += 1;
            num[aux] = matriz[i][j];
            aux += 1;
           } else{
            num[aux] = 0;
            aux += 1;
            }
        }
    }

    //mostrando quantidade e quais.
    printf("\nNumeros maiores que 5: %d, sao eles: ", cont);
    for (int i = 0; i < 6 ; i++){
        if(num[i] != 0 && num[i] > 5){
            printf("\nNumero: %d", num[i]);
        }
    }
}