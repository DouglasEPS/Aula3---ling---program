//Exercício 4: 
//Matriz 3×3 - calcular soma da diagonal principal 

# include <stdio.h>

int main() {
    int matriz[3][3];
    
    //insere os valores que quiser
    printf("Digite os valores da matriz\n");
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            printf("Elemento[%d][%d]: ", i+1, j+1);
            scanf("%d", &matriz[i][j]);
        }
    }

    printf("\nMatriz digitada:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n"); // quebra linha a cada linha da matriz
    }

    //soma da diagonal pricipal

    int soma = (matriz[0][0] + matriz[1][1] + matriz[2][2]);
    printf("\nSoma da diagonal principal: %d", soma);

    return 0;
}