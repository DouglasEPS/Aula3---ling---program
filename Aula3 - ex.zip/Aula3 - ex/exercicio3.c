//Exercício 3:
//Criar uma matriz 2×2, preenchê-la e encontrar o maior elemento.

# include <stdio.h>

int main() {
    int matriz[2][2];
    int maior = 0;
    //insere os valores que quiser
    printf("Digite os valores da matriz\n");
    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 2; j++){
            printf("Elemento[%d][%d]: ", i+1, j+1);
            scanf("%d", &matriz[i][j]);
        }
    }

    printf("\nMatriz digitada:\n");
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n"); // quebra linha a cada linha da matriz
    }
    
    //procura 
    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 2; j++){
            if(matriz[i][j] > maior){
                maior = matriz[i][j];
            }
        }
    }

    printf("\nO maior valor da matriz e: %d", maior);
    return 0;
}